package com.example.calendar;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class CalendarActivity extends AppCompatActivity {

    private CalendarView calendarView;
    private TextView textSelectedDate;
    private Button btnSaveDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar);

        calendarView = findViewById(R.id.calendarView);
        textSelectedDate = findViewById(R.id.textSelectedDate);
        btnSaveDate = findViewById(R.id.btnSaveDate);

        // Configura el listener per al calendari
        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                // Actualitza el TextView amb la data seleccionada
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                Calendar selectedDateCalendar = Calendar.getInstance();
                selectedDateCalendar.set(year, month, dayOfMonth);
                textSelectedDate.setText("Selected date: " + sdf.format(selectedDateCalendar.getTime()));
            }
        });

        // Configura el listener per al botó de guardar data
        btnSaveDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Obté la data seleccionada del TextView
                String selectedDateStr = textSelectedDate.getText().toString();

                // Mostra un pop-up amb la data s'ha guardat correctament
                showAlertDialog("Saved Date", "Date: " + selectedDateStr);
            }
        });
    }

    // Mètode per mostrar un AlertDialog amb un missatge i un botó de tancar
    private void showAlertDialog(String title, String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(title)
                .setMessage(message)
                .setPositiveButton("close", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // Tancar el pop-up
                        dialog.dismiss();
                    }
                });

        AlertDialog dialog = builder.create();
        dialog.show();
    }
}
